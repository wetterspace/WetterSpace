//window.onresize = function(){ location.reload(); }
